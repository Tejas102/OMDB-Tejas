//
//  omdb_tejasApp.swift
//  omdb_tejas
//
//  Created by tejas jadhav on 2022-09-07.
//

import SwiftUI

@main
struct omdb_tejasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
