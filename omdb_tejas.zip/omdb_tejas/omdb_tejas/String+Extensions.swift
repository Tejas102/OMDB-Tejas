//
//  String+Extensions.swift
//  omdb_tejas
//
//  Created by tejas jadhav on 2022-09-07.
//

import Foundation

extension String {
    func trimmed() -> String {
        self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
